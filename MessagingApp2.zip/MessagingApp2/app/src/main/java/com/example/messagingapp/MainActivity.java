package com.example.messagingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


public class MainActivity extends AppCompatActivity {


    private FirebaseAuth mAuth;
    private EditText email_field;
    private EditText password_field;
    private FirebaseFirestore firestore;
    private FirebaseUser user;
    private String userid;
    private String Mynumber;
    public static final String EXTRA_MESSAGE = "com.example.messagingapp.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth=FirebaseAuth.getInstance();
        userid=mAuth.getUid();
        email_field = findViewById(R.id.editText);
        password_field = findViewById(R.id.editText2);
        firestore=FirebaseFirestore.getInstance();

    }

    public void sign_in_button(View view) {
        String email=email_field.getText().toString();
        String password = password_field.getText().toString();

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            user = mAuth.getCurrentUser();
                            getuserPhone(new myCallback() {
                                @Override
                                public void onCallback(String s) {
                                    Intent intent = new Intent(MainActivity.this, DisplayMessageActivity.class);
                                    intent.putExtra(EXTRA_MESSAGE, Mynumber);
                                    startActivity(intent);
                                }
                            });
                        }
                        else {
                            email_field.setText("");
                            password_field.setText("");
                        }
                    }
                });
    }

    public void sign_up_button(View view) {
        Intent intent = new Intent(MainActivity.this, Sign_up.class);
        startActivity(intent);
    }

    public void getuserPhone(final myCallback callback){
        firestore.collection("UID").document(userid).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot documentSnapshot=task.getResult();
                        Mynumber=(String) documentSnapshot.get("phoneno");
                        callback.onCallback(Mynumber);
                    }
                });
    }

    private interface myCallback{
        void onCallback(String s);
    }



    @Override
    protected void onStart() {
        super.onStart();
        if (mAuth.getCurrentUser() != null) {
            getuserPhone(new myCallback() {
                @Override
                public void onCallback(String s) {
                    Intent intent = new Intent(MainActivity.this, DisplayMessageActivity.class);
                    intent.putExtra(EXTRA_MESSAGE, Mynumber);
                    startActivity(intent);
                }
            });

        }
    }

}




