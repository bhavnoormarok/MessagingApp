package com.example.messagingapp;

public class Contact {
    String Username;
    String Id;

    public Contact(String Username, String Id) {
        this.Username = Username;
        this.Id = Id;
    }

    public String getUsername() {
        return Username;
    }

    public String getId() {
        return Id;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public void setId(String id) {
        Id = id;
    }
}
