package com.example.messagingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class new_contact extends AppCompatActivity {
    private Button add;
    private EditText name;
    private EditText id;
    private FirebaseFirestore fire_store;
    private String Mynumber;
    private String number1;
    private String DocumentId;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_contact);
        add=findViewById(R.id.button5);
        name=findViewById(R.id.editText8);
        id=findViewById(R.id.editText4);
        fire_store=FirebaseFirestore.getInstance();
        Intent intent=getIntent();
        Mynumber=intent.getStringExtra(DisplayMessageActivity.EXTRA_MESSAGE1);



        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Username=name.getText().toString();
                number1=id.getText().toString();


                if (Mynumber.matches("[0-9]+") && Mynumber.length() > 2) {
                    fire_store.collection("user").document(Mynumber).update("contacts." + number1, Username).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void a) {


                            DocumentId=Mynumber+"&"+number1;
                            if(Mynumber.compareTo(number1)>0){
                                DocumentId =number1+"&"+Mynumber;
                            }

                            fire_store.collection("messages").document(DocumentId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if(! task.isSuccessful()){
                                        Map<String, ArrayList<String>> s= new HashMap<>();
                                        ArrayList<String> array= new ArrayList<>();
                                        array.add(Mynumber+"/hi");
                                        s.put("message",array);
                                        fire_store.collection("messages").document(DocumentId).set(s);
                                        fire_store.collection("messages").document(DocumentId).update("message",FieldValue.arrayRemove(Mynumber+"/hi"));
                                    }
                                    Intent intent = new Intent (new_contact.this, DisplayMessageActivity.class);
                                    startActivity(intent);
                                }
                            });

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(new_contact.this, "error", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else {
                    Toast.makeText(new_contact.this, "Enter Valid Details", Toast.LENGTH_SHORT).show();
                    id.setText("");
                }
            }
        });
    }
}
