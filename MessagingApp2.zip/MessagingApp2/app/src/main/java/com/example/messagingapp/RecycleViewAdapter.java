package com.example.messagingapp;

import android.view.LayoutInflater;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewHolder> {
    private DisplayMessageActivity dma;
    private ArrayList<Contact> userlist;
    private listener listen;

    public RecycleViewAdapter(DisplayMessageActivity dma, ArrayList<Contact> userlist, listener listen) {
        this.dma = dma;
        this.userlist = userlist;
        this.listen=listen;
    }

    @NonNull
    @Override
    public RecycleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater= LayoutInflater.from(dma.getBaseContext());
        View view= layoutInflater.inflate(R.layout.singlerow, parent,false);
        return new RecycleViewHolder(view, listen);
    }

    @Override
    public void onBindViewHolder(@NonNull RecycleViewHolder holder, int position) {
        holder.Username.setText(userlist.get(position).getUsername());
        holder.Id.setText(userlist.get(position).getId());

    }

    @Override
    public int getItemCount() {
        return userlist.size();
    }

    public interface listener{
        void click(int position);
    }
}
