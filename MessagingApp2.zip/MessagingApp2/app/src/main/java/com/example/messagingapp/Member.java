package com.example.messagingapp;

public class Member {
    private String email;

    public Member(String email) {
        this.email = email;
    }

}
