package com.example.messagingapp;


import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;

public class messagesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private FirebaseFirestore firestore;
    private ArrayList<String> messages;
    private EditText WriteMessage;
    private Button send;
    private String number1;
    private String number2;
    private String DocumentID;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messages);

        Intent intent = getIntent();
        number1=intent.getStringExtra(DisplayMessageActivity.EXTRA_MESSAGE1).split(" ",2)[0];
        number2=intent.getStringExtra(DisplayMessageActivity.EXTRA_MESSAGE1).split(" ",2)[1];

        recyclerView = findViewById(R.id.messagerecyclerview);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        firestore = FirebaseFirestore.getInstance();
        messages = new ArrayList<>();
        WriteMessage= findViewById(R.id.editText5);
        send= findViewById(R.id.button6);
        DocumentID=number2+"&"+number1;
        if(number2.compareTo(number1)>0){
            DocumentID=number1+"&"+number2;
        };


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=WriteMessage.getText().toString();
                if(!s.isEmpty()) {
                    s = number2 + '/' + s;
                    messages.add(s);
                    firestore.collection("messages").document(DocumentID).update("message", messages);
                    WriteMessage.setText("");
                }
            }
        });

        loadmessages();
    }

    private void loadmessages() {


        firestore.collection("messages").document(DocumentID).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                if (messages.size() > 0) {
                    messages.clear();
                }
                ArrayList<String> message = (ArrayList<String>) documentSnapshot.get("message");

                for (int i=0; i<message.size(); i++) {
                    messages.add(message.get(i));
                }
                adapter = new MessageViewAdapter(messagesActivity.this, messages, number1, number2);
                recyclerView.setAdapter(adapter);
            }
        });
    }
}