package com.example.messagingapp;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class MessageViewHolder extends RecyclerView.ViewHolder {
    public TextView text;
    public MessageViewHolder(View v){
        super(v);
        text=v.findViewById(R.id.textView7);
    }
}
