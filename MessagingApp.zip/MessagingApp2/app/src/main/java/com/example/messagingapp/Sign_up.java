package com.example.messagingapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


public class Sign_up extends AppCompatActivity {

    private FirebaseAuth Auth;
    private EditText email_field;
    private FirebaseUser user;
    private FirebaseFirestore firestore;

    private EditText password1_field;
    private EditText password2_field;
    private Button Create;
    private EditText phoneno_field;
    private String email,password1,password2, phoneno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        Auth=FirebaseAuth.getInstance();
        firestore=FirebaseFirestore.getInstance();

        email_field= findViewById(R.id.editText3);
        password1_field= findViewById(R.id.editText6);
        password2_field= findViewById(R.id.editText7);
        phoneno_field= findViewById(R.id.editText9);
        Create= findViewById(R.id.button);




        Create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = email_field.getText().toString();
                password1 = password1_field.getText().toString();
                password2 = password2_field.getText().toString();
                phoneno=phoneno_field.getText().toString();
                signup();
            }
        });

    }

    public void signup() {
        if(password1.equals(password2)) {
            Auth.createUserWithEmailAndPassword(email, password1)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                user = Auth.getCurrentUser();
                                Map<String,Map<String,String>> q=new HashMap<>();
                                Map<String,String> r=new HashMap<>();
                                Map<String,String> w=new HashMap<>();
                                w.put("phoneno",phoneno);
                                r.put("sample","");
                                firestore.collection("UID").document(Objects.requireNonNull(Auth.getUid())).set(w);
                                q.put("contacts",r);
                                firestore.collection("user").document(phoneno).set(q);
                                firestore.collection("user").document(phoneno).update("contacts.sample", FieldValue.delete());
                                Intent intent= new Intent(Sign_up.this,MainActivity.class);
                                startActivity(intent);
                            } else {
                                return;
                            }
                        }
                    });
        }
        else {
            password2_field.setText("");
            password1_field.setText("");
        }
    }



    public void signin() {

        Auth.signInWithEmailAndPassword(email, password1)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            user = Auth.getCurrentUser();
                            firestore.collection("UID phoneno map").document(user.getUid()).update("phoneNo",phoneno);
                            Map<String, Map<String,String>> map = new HashMap<>();
                            firestore.collection("user").document(phoneno).set(map);
                            Intent intent= new Intent(Sign_up.this,MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });
    }
}
