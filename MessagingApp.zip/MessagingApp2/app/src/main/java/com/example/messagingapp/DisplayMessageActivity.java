package com.example.messagingapp;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

public class DisplayMessageActivity extends AppCompatActivity implements RecycleViewAdapter.listener{
    private Button add, logout;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private FirebaseFirestore firestore;
    private FirebaseAuth auth;
    private ArrayList<Contact> contactlist;
    private TextView v;
    public static final String EXTRA_MESSAGE1 = "com.example.messagingapp.MESSAGE";
    private String number2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_mesage);
        recyclerView = findViewById(R.id.my_recycler_view);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        firestore = FirebaseFirestore.getInstance();
        contactlist = new ArrayList<>();
        add = findViewById(R.id.button4);
        auth=FirebaseAuth.getInstance();
        logout= findViewById(R.id.button7);
        Intent intent = getIntent();
        v=findViewById(R.id.textView8);
        number2= intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        v.setText(number2);
        loadContact();


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DisplayMessageActivity.this, new_contact.class);
                intent.putExtra(EXTRA_MESSAGE1, number2);
                startActivity(intent);
            }
        });


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth.signOut();
                Intent intent = new Intent(DisplayMessageActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void loadContact() {
        if (contactlist.size() > 0) {
            contactlist.clear();
        }

       firestore.collection("user").document(number2).addSnapshotListener(new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                        Map<String,String> users = (Map<String,String>) documentSnapshot.get("contacts");
                        Set<Map.Entry<String, String>> setofEntries = users.entrySet();
                        for(Map.Entry<String,String> entry:setofEntries) {
                            Contact user1 = new Contact(entry.getValue(), entry.getKey());
                            contactlist.add(user1);
                        }
                        adapter = new RecycleViewAdapter(DisplayMessageActivity.this, contactlist,DisplayMessageActivity.this);
                        recyclerView.setAdapter(adapter);
                    }
                });


    }


    public void click(int position){
        final Intent intent1 = new Intent(this, messagesActivity.class);
        String number1=contactlist.get(position).getId();
        intent1.putExtra(EXTRA_MESSAGE1, number1+" "+number2);

        startActivity(intent1);
    }
}


