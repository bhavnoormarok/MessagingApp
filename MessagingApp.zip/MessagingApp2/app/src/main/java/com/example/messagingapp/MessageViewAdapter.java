package com.example.messagingapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MessageViewAdapter extends RecyclerView.Adapter<MessageViewHolder> {
    private messagesActivity messagesactivity;
    private ArrayList<String> messages;
    private boolean s=true;
    private String number1, number2;

    public MessageViewAdapter(messagesActivity messagesactivity, ArrayList<String> messages, String number1, String number2) {
        this.messagesactivity = messagesactivity;
        this.messages = messages;
        this.number1=number1;
        this.number2=number2;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (s==true) {
            LayoutInflater layoutInflater = LayoutInflater.from(messagesactivity.getBaseContext());
            view = layoutInflater.inflate(R.layout.singlemessage1, parent, false);
        }
        else {
            LayoutInflater layoutInflater = LayoutInflater.from(messagesactivity.getBaseContext());
            view = layoutInflater.inflate(R.layout.singlemessage2, parent, false);
        }

        return new MessageViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        if (messages.get(position).startsWith(number1)) {
            s = true;
            holder.text.setText(messages.get(position).replaceFirst(number1+"/",""));
        }
        else {
            s=false;
            holder.text.setText(messages.get(position).replaceFirst(number2+"/",""));
        }

    }

    @Override
    public int getItemCount() {
        return messages.size();
    }
}
