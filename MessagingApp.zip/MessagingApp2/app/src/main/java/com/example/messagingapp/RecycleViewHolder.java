package com.example.messagingapp;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class RecycleViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public TextView Username, Id;
    RecycleViewAdapter.listener listen;
    public RecycleViewHolder(View view, RecycleViewAdapter.listener listen){
        super(view);
        Username=view.findViewById(R.id.Username);
        Id=view.findViewById(R.id.Id);
        this.listen=listen;

        view.setOnClickListener(this );
    }

    @Override
    public void onClick(View v) {
       listen.click(getAdapterPosition());
    }
}
